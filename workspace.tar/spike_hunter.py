"""
SpikeHunter - Python Implementation of MQL5 Spike Hunter EA
============================================================
Converted from MQL5 to Python with backtesting and optimization capabilities.
Strategy: Identifies price spikes based on BB/KC Squeeze, Market Structure Breakout,
Liquidity Sweep Reversal, Momentum Acceleration, and Tick Volume Surge.

Data Source: Dukascopy (XAUUSD M5)
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta, timezone
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# DATA ACQUISITION
# ============================================================
def download_gold_data():
    """Download 2 months of XAUUSD M5 data from Dukascopy"""
    try:
        import dukascopy_python as duka
        
        end_date = datetime.now(timezone.utc) - timedelta(days=1)
        start_date = end_date - timedelta(days=60)
        
        print(f"Downloading XAUUSD M5 data from {start_date.date()} to {end_date.date()}...")
        
        candles = list(duka.fetch_candles(
            instrument="XAU-USD",
            interval=5,
            time_unit=duka.TimeUnit.MINUTE,
            offer_side=duka.OfferSide.BID,
            start=start_date,
            end=end_date,
            version=2,
        ))
        
        df = duka.to_dataframe(candles)
        df.columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume', 'time_unit', 'interval']
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.set_index('timestamp')
        df = df[['open', 'high', 'low', 'close', 'volume']]
        df = df.astype(float)
        
        print(f"Downloaded {len(df)} bars successfully.")
        return df
        
    except Exception as e:
        print(f"Dukascopy download failed: {e}")
        print("Trying alternative data source...")
        return download_gold_data_alternative()


def download_gold_data_alternative():
    """Alternative: Use compat API"""
    try:
        import dukascopy_python.compat as duka_compat
        
        end_date = datetime.now(timezone.utc) - timedelta(days=1)
        start_date = end_date - timedelta(days=60)
        
        print(f"Trying compat API: {start_date.date()} to {end_date.date()}...")
        
        df = duka_compat.fetch(
            "XAU/USD",
            duka_compat.INTERVAL_MIN_5,
            duka_compat.OFFER_SIDE_BID,
            start_date,
            end_date,
        )
        
        df.columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume']
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df = df.set_index('timestamp')
        df = df.astype(float)
        
        print(f"Downloaded {len(df)} bars via compat API.")
        return df
        
    except Exception as e:
        print(f"Compat API also failed: {e}")
        print("Generating synthetic XAUUSD M5 data for backtesting...")
        return generate_synthetic_gold_data()


def generate_synthetic_gold_data():
    """Generate realistic synthetic XAUUSD M5 data for 2 months"""
    np.random.seed(42)
    
    # 2 months of M5 data (~17,000 bars for 24/5 market)
    # Gold trades ~23h/day, 5 days/week = ~66 days * 276 bars/day ≈ 18,000 bars
    n_bars = 17500
    
    start = datetime(2026, 1, 5, 0, 0, 0)
    timestamps = pd.date_range(start=start, periods=n_bars, freq='5min')
    
    # Remove weekends
    timestamps = timestamps[timestamps.dayofweek < 5]
    n_bars = len(timestamps)
    
    # Base price around current gold levels
    base_price = 3250.0
    
    # Generate realistic price movement with:
    # - Trend component
    # - Mean reversion
    # - Volatility clustering (GARCH-like)
    # - Occasional spikes
    
    prices = np.zeros(n_bars)
    prices[0] = base_price
    
    # Volatility clustering
    vol = 0.5  # base volatility in $ per 5min bar
    mu = 0.0001  # slight upward drift
    
    for i in range(1, n_bars):
        # GARCH-like volatility
        vol = 0.3 + 0.7 * vol + 0.1 * abs(np.random.normal(0, 0.3))
        vol = min(vol, 5.0)
        
        # Normal movement
        ret = mu + vol * np.random.normal(0, 1) / base_price
        
        # Occasional spikes (about 1 in 200 bars)
        if np.random.random() < 0.005:
            ret += np.random.choice([-1, 1]) * np.random.uniform(2, 8) / base_price
        
        # Squeeze periods (consolidation followed by breakout)
        if i % 500 < 30:  # 30 bars of consolidation every 500 bars
            ret *= 0.2
        
        prices[i] = prices[i-1] * (1 + ret)
    
    # Generate OHLC from close prices
    df = pd.DataFrame(index=timestamps[:n_bars])
    df['close'] = prices
    
    # Generate realistic OHLC
    noise = np.random.uniform(0.1, 1.5, n_bars)
    df['high'] = df['close'] + noise * vol * 0.5
    df['low'] = df['close'] - noise * vol * 0.5
    df['open'] = df['close'].shift(1) + np.random.normal(0, 0.1, n_bars)
    df['open'].iloc[0] = df['close'].iloc[0]
    
    # Ensure high >= max(open, close) and low <= min(open, close)
    df['high'] = df[['open', 'high', 'close']].max(axis=1)
    df['low'] = df[['open', 'low', 'close']].min(axis=1)
    
    # Generate tick volume
    base_vol = 500
    df['volume'] = (base_vol + np.random.exponential(200, n_bars)).astype(int)
    # Volume spikes during big moves
    df['volume'] = df['volume'] * (1 + 2 * np.abs(df['close'] - df['open']) / vol)
    df['volume'] = df['volume'].astype(int)
    
    print(f"Generated {len(df)} synthetic XAUUSD M5 bars.")
    return df


# ============================================================
# TECHNICAL INDICATORS
# ============================================================
def calc_ema(series, period):
    """Exponential Moving Average"""
    return series.ewm(span=period, adjust=False).mean()

def calc_sma(series, period):
    """Simple Moving Average"""
    return series.rolling(window=period).mean()

def calc_atr(df, period=14):
    """Average True Range"""
    high = df['high']
    low = df['low']
    close = df['close']
    
    tr1 = high - low
    tr2 = abs(high - close.shift(1))
    tr3 = abs(low - close.shift(1))
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    
    atr = tr.ewm(span=period, adjust=False).mean()
    return atr

def calc_bollinger_bands(df, period=20, std_dev=2.0):
    """Bollinger Bands"""
    middle = calc_sma(df['close'], period)
    std = df['close'].rolling(window=period).std()
    upper = middle + std_dev * std
    lower = middle - std_dev * std
    return upper, middle, lower

def calc_keltner_channels(df, ema_period=20, atr_period=14, atr_mult=1.5):
    """Keltner Channels"""
    ema = calc_ema(df['close'], ema_period)
    atr = calc_atr(df, atr_period)
    upper = ema + atr_mult * atr
    lower = ema - atr_mult * atr
    return upper, ema, lower


# ============================================================
# SPIKE HUNTER STRATEGY
# ============================================================
class SpikeHunterParams:
    """Strategy parameters (equivalent to MQL5 input parameters)"""
    def __init__(self, **kwargs):
        # Squeeze settings
        self.bb_period = kwargs.get('bb_period', 20)
        self.bb_deviation = kwargs.get('bb_deviation', 2.0)
        self.kc_period = kwargs.get('kc_period', 20)
        self.atr_period = kwargs.get('atr_period', 14)
        self.kc_atr_mult = kwargs.get('kc_atr_mult', 1.5)
        self.min_squeeze_bars = kwargs.get('min_squeeze_bars', 3)
        self.squeeze_lookback = kwargs.get('squeeze_lookback', 8)
        self.use_atr_compression = kwargs.get('use_atr_compression', True)
        self.atr_slow_period = kwargs.get('atr_slow_period', 50)
        self.atr_comp_ratio_max = kwargs.get('atr_comp_ratio_max', 0.80)
        
        # Structure settings
        self.struct_period = kwargs.get('struct_period', 15)
        self.trade_breakouts = kwargs.get('trade_breakouts', True)
        self.trade_sweep_reversal = kwargs.get('trade_sweep_reversal', True)
        self.min_body_ratio = kwargs.get('min_body_ratio', 0.55)
        self.sweep_wick_ratio = kwargs.get('sweep_wick_ratio', 0.45)
        self.min_range_atr = kwargs.get('min_range_atr', 1.15)
        self.max_range_atr = kwargs.get('max_range_atr', 2.80)
        self.max_stretch_atr = kwargs.get('max_stretch_atr', 2.50)
        
        # Momentum settings
        self.ema_fast_period = kwargs.get('ema_fast_period', 9)
        self.ema_slow_period = kwargs.get('ema_slow_period', 21)
        self.require_accel = kwargs.get('require_accel', True)
        self.vol_ma_period = kwargs.get('vol_ma_period', 20)
        self.min_vol_mult = kwargs.get('min_vol_mult', 1.40)
        
        # Risk management
        self.sl_atr_mult = kwargs.get('sl_atr_mult', 1.50)
        self.rr_ratio = kwargs.get('rr_ratio', 2.20)
        self.use_breakeven = kwargs.get('use_breakeven', True)
        self.be_trigger_r = kwargs.get('be_trigger_r', 1.00)
        self.be_offset_points = kwargs.get('be_offset_points', 0.05)  # $0.05 for gold
        self.use_atr_trailing = kwargs.get('use_atr_trailing', True)
        self.trail_start_r = kwargs.get('trail_start_r', 1.30)
        self.trail_atr_mult = kwargs.get('trail_atr_mult', 1.20)
        self.use_time_stop = kwargs.get('use_time_stop', True)
        self.max_hold_bars = kwargs.get('max_hold_bars', 12)
        
        # Execution
        self.cooldown_bars = kwargs.get('cooldown_bars', 3)
        self.max_spread = kwargs.get('max_spread', 0.50)  # $0.50 spread for gold
        self.risk_percent = kwargs.get('risk_percent', 1.0)
        self.initial_balance = kwargs.get('initial_balance', 10000.0)


class SpikeHunterBacktester:
    """Backtesting engine for Spike Hunter strategy"""
    
    def __init__(self, df, params=None):
        self.df = df.copy()
        self.params = params or SpikeHunterParams()
        self.trades = []
        self.equity_curve = []
        
    def prepare_indicators(self):
        """Calculate all required indicators"""
        p = self.params
        df = self.df
        
        # ATR
        df['atr'] = calc_atr(df, p.atr_period)
        df['atr_slow'] = calc_atr(df, p.atr_slow_period)
        
        # Bollinger Bands
        df['bb_upper'], df['bb_middle'], df['bb_lower'] = calc_bollinger_bands(
            df, p.bb_period, p.bb_deviation
        )
        
        # Keltner Channels
        df['kc_upper'], df['kc_ema'], df['kc_lower'] = calc_keltner_channels(
            df, p.kc_period, p.atr_period, p.kc_atr_mult
        )
        
        # EMAs
        df['ema_fast'] = calc_ema(df['close'], p.ema_fast_period)
        df['ema_slow'] = calc_ema(df['close'], p.ema_slow_period)
        
        # Volume MA
        df['vol_ma'] = calc_sma(df['volume'].astype(float), p.vol_ma_period)
        
        # Candle metrics
        df['range'] = df['high'] - df['low']
        df['body'] = abs(df['close'] - df['open'])
        df['body_ratio'] = df['body'] / df['range']
        df['upper_wick'] = df['high'] - df[['open', 'close']].max(axis=1)
        df['lower_wick'] = df[['open', 'close']].min(axis=1) - df['low']
        df['u_wick_ratio'] = df['upper_wick'] / df['range']
        df['l_wick_ratio'] = df['lower_wick'] / df['range']
        
        # Structure levels (rolling high/low)
        df['struct_high'] = df['high'].rolling(window=p.struct_period, min_periods=1).max().shift(1)
        df['struct_low'] = df['low'].rolling(window=p.struct_period, min_periods=1).min().shift(1)
        
        # Velocity and acceleration
        df['vel'] = df['close'] - df['close'].shift(1)
        df['vel_prev'] = df['vel'].shift(1)
        
        # Squeeze detection (BB inside KC)
        df['squeeze'] = (df['bb_upper'] < df['kc_upper']) & (df['bb_lower'] > df['kc_lower'])
        
        # ATR compression ratio
        df['atr_ratio'] = df['atr'] / df['atr_slow']
        
        return df
    
    def detect_squeeze(self, idx):
        """Check if squeeze condition is met at given index"""
        p = self.params
        df = self.df
        
        # Check consecutive squeeze bars
        consecutive = 0
        for i in range(idx - 1, max(idx - p.squeeze_lookback - p.min_squeeze_bars - 1, 0), -1):
            if i < 0:
                break
            if df.iloc[i]['squeeze']:
                consecutive += 1
                if consecutive >= p.min_squeeze_bars:
                    return True
            else:
                consecutive = 0
        
        # Check ATR compression
        if p.use_atr_compression:
            if df.iloc[idx]['atr_ratio'] <= p.atr_comp_ratio_max:
                return True
        
        return False
    
    def evaluate_signal(self, idx):
        """Evaluate spike signal at given bar index"""
        p = self.params
        df = self.df
        
        if idx < max(p.struct_period + 5, p.squeeze_lookback + p.min_squeeze_bars + 5, p.vol_ma_period + 5):
            return 0, ""
        
        row = df.iloc[idx]
        prev = df.iloc[idx - 1]
        prev2 = df.iloc[idx - 2]
        
        cur_atr = row['atr']
        if cur_atr <= 0 or np.isnan(cur_atr):
            return 0, ""
        
        # 1. Squeeze detection
        if not self.detect_squeeze(idx):
            return 0, ""
        
        # 2. Range filter
        range_atr = row['range'] / cur_atr
        if range_atr < p.min_range_atr or range_atr > p.max_range_atr:
            return 0, ""
        
        # 3. Stretch filter
        stretch_atr = abs(row['close'] - row['ema_slow']) / cur_atr
        if stretch_atr > p.max_stretch_atr:
            return 0, ""
        
        # 4. Volume filter
        if row['volume'] < row['vol_ma'] * p.min_vol_mult:
            return 0, ""
        if row['volume'] <= prev['volume']:
            return 0, ""
        
        # 5. Structure levels
        struct_high = row['struct_high']
        struct_low = row['struct_low']
        
        if np.isnan(struct_high) or np.isnan(struct_low):
            return 0, ""
        
        # 6. Candle anatomy
        body_ratio = row['body_ratio']
        u_wick_ratio = row['u_wick_ratio']
        l_wick_ratio = row['l_wick_ratio']
        
        # 7. Momentum
        vel = row['vel']
        vel_prev = row['vel_prev']
        
        bull_accel = (not p.require_accel) or (vel > 0 and vel > vel_prev)
        bear_accel = (not p.require_accel) or (vel < 0 and vel < vel_prev)
        bull_trend = row['ema_fast'] > row['ema_slow'] and row['close'] > row['ema_slow']
        bear_trend = row['ema_fast'] < row['ema_slow'] and row['close'] < row['ema_slow']
        
        signal_dir = 0
        signal_type = ""
        
        # Breakout signals
        if p.trade_breakouts:
            if (row['close'] > struct_high and row['close'] > row['open'] and
                body_ratio >= p.min_body_ratio and bull_trend and bull_accel):
                signal_dir = 1
                signal_type = "Breakout_Buy"
            elif (row['close'] < struct_low and row['close'] < row['open'] and
                  body_ratio >= p.min_body_ratio and bear_trend and bear_accel):
                signal_dir = -1
                signal_type = "Breakout_Sell"
        
        # Sweep reversal signals
        if signal_dir == 0 and p.trade_sweep_reversal:
            if (row['low'] < struct_low and row['close'] > struct_low and
                l_wick_ratio >= p.sweep_wick_ratio and row['close'] > row['open'] and vel > 0):
                signal_dir = 1
                signal_type = "SweepReversal_Buy"
            elif (row['high'] > struct_high and row['close'] < struct_high and
                  u_wick_ratio >= p.sweep_wick_ratio and row['close'] < row['open'] and vel < 0):
                signal_dir = -1
                signal_type = "SweepReversal_Sell"
        
        return signal_dir, signal_type
    
    def run_backtest(self):
        """Run the full backtest"""
        self.prepare_indicators()
        
        p = self.params
        balance = p.initial_balance
        equity = balance
        position = None  # {direction, entry_price, sl, tp, entry_idx, entry_time, lots}
        last_trade_idx = -999
        
        results = []
        
        for idx in range(len(self.df)):
            row = self.df.iloc[idx]
            cur_atr = row['atr']
            
            # Manage open position
            if position is not None:
                exit_price, exit_reason = self._manage_position(position, idx)
                
                if exit_price is not None:
                    # Close position
                    pnl = position['direction'] * (exit_price - position['entry_price']) * position['lots']
                    balance += pnl
                    
                    trade_result = {
                        'entry_time': position['entry_time'],
                        'exit_time': self.df.index[idx],
                        'direction': position['direction'],
                        'entry_price': position['entry_price'],
                        'exit_price': exit_price,
                        'sl': position['sl'],
                        'tp': position['tp'],
                        'lots': position['lots'],
                        'pnl': pnl,
                        'pnl_pct': pnl / p.initial_balance * 100,
                        'exit_reason': exit_reason,
                        'signal_type': position['signal_type'],
                        'bars_held': idx - position['entry_idx']
                    }
                    self.trades.append(trade_result)
                    position = None
            
            # Check for new entry
            if position is None and (idx - last_trade_idx) >= p.cooldown_bars:
                signal_dir, signal_type = self.evaluate_signal(idx)
                
                if signal_dir != 0:
                    entry_price = row['close']
                    
                    # Calculate SL
                    sl_dist = max(cur_atr * p.sl_atr_mult, 0.5)
                    
                    if signal_dir == 1:
                        sl_price = entry_price - sl_dist
                        bar_sl = row['low'] - 0.1
                        sl_price = min(sl_price, bar_sl)
                        if entry_price - sl_price > sl_dist * 1.8:
                            sl_price = entry_price - sl_dist
                        risk_dist = entry_price - sl_price
                        tp_price = entry_price + risk_dist * p.rr_ratio
                    else:
                        sl_price = entry_price + sl_dist
                        bar_sl = row['high'] + 0.1
                        sl_price = max(sl_price, bar_sl)
                        if sl_price - entry_price > sl_dist * 1.8:
                            sl_price = entry_price + sl_dist
                        risk_dist = sl_price - entry_price
                        tp_price = entry_price - risk_dist * p.rr_ratio
                    
                    # Position sizing
                    risk_money = balance * (p.risk_percent / 100.0)
                    if risk_dist > 0:
                        lots = risk_money / risk_dist
                        lots = max(0.01, min(lots, 10.0))
                    else:
                        lots = 0.01
                    
                    position = {
                        'direction': signal_dir,
                        'entry_price': entry_price,
                        'sl': sl_price,
                        'tp': tp_price,
                        'entry_idx': idx,
                        'entry_time': self.df.index[idx],
                        'lots': lots,
                        'signal_type': signal_type,
                        'initial_risk': risk_dist,
                        'highest_profit_r': 0.0
                    }
                    last_trade_idx = idx
            
            # Track equity
            unrealized = 0
            if position is not None:
                unrealized = position['direction'] * (row['close'] - position['entry_price']) * position['lots']
            
            equity = balance + unrealized
            self.equity_curve.append(equity)
        
        return self._compile_results()
    
    def _manage_position(self, pos, idx):
        """Manage open position - check SL, TP, trailing, breakeven, time stop"""
        p = self.params
        row = self.df.iloc[idx]
        cur_atr = row['atr']
        
        if np.isnan(cur_atr) or cur_atr <= 0:
            return None, None
        
        bars_held = idx - pos['entry_idx']
        current_price = row['close']
        profit_dist = pos['direction'] * (current_price - pos['entry_price'])
        r_multiple = profit_dist / pos['initial_risk'] if pos['initial_risk'] > 0 else 0
        
        pos['highest_profit_r'] = max(pos['highest_profit_r'], r_multiple)
        
        # Check SL hit
        if pos['direction'] == 1:
            if row['low'] <= pos['sl']:
                return pos['sl'], "SL"
        else:
            if row['high'] >= pos['sl']:
                return pos['sl'], "SL"
        
        # Check TP hit
        if pos['direction'] == 1:
            if row['high'] >= pos['tp']:
                return pos['tp'], "TP"
        else:
            if row['low'] <= pos['tp']:
                return pos['tp'], "TP"
        
        # Time stop
        if p.use_time_stop and p.max_hold_bars > 0:
            if bars_held >= p.max_hold_bars and r_multiple < 0.5:
                return current_price, "TimeStop"
        
        # Breakeven
        if p.use_breakeven and r_multiple >= p.be_trigger_r:
            if pos['direction'] == 1:
                be_price = pos['entry_price'] + p.be_offset_points
                pos['sl'] = max(pos['sl'], be_price)
            else:
                be_price = pos['entry_price'] - p.be_offset_points
                pos['sl'] = min(pos['sl'], be_price)
        
        # ATR Trailing Stop
        if p.use_atr_trailing and r_multiple >= p.trail_start_r:
            trail_dist = cur_atr * p.trail_atr_mult
            if pos['direction'] == 1:
                trail_sl = current_price - trail_dist
                pos['sl'] = max(pos['sl'], trail_sl)
            else:
                trail_sl = current_price + trail_dist
                pos['sl'] = min(pos['sl'], trail_sl)
        
        return None, None
    
    def _compile_results(self):
        """Compile backtest results"""
        if not self.trades:
            return {
                'total_trades': 0,
                'net_profit': 0,
                'win_rate': 0,
                'profit_factor': 0,
                'max_drawdown': 0,
                'sharpe_ratio': 0,
                'avg_trade_pnl': 0,
                'avg_bars_held': 0,
                'final_balance': self.params.initial_balance,
                'trades': []
            }
        
        trades_df = pd.DataFrame(self.trades)
        equity_df = pd.Series(self.equity_curve)
        
        # Basic stats
        total_trades = len(trades_df)
        winners = trades_df[trades_df['pnl'] > 0]
        losers = trades_df[trades_df['pnl'] <= 0]
        
        net_profit = trades_df['pnl'].sum()
        win_rate = len(winners) / total_trades * 100 if total_trades > 0 else 0
        
        gross_profit = winners['pnl'].sum() if len(winners) > 0 else 0
        gross_loss = abs(losers['pnl'].sum()) if len(losers) > 0 else 0
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
        
        # Drawdown
        peak = equity_df.expanding().max()
        drawdown = (equity_df - peak) / peak * 100
        max_drawdown = drawdown.min()
        
        # Sharpe ratio (annualized, assuming 252 trading days * ~280 bars/day for M5)
        returns = equity_df.pct_change().dropna()
        if len(returns) > 1 and returns.std() > 0:
            sharpe = (returns.mean() / returns.std()) * np.sqrt(252 * 280)
        else:
            sharpe = 0
        
        avg_trade_pnl = trades_df['pnl'].mean()
        avg_bars_held = trades_df['bars_held'].mean()
        
        # Exit reason analysis
        exit_reasons = trades_df['exit_reason'].value_counts().to_dict()
        
        results = {
            'total_trades': total_trades,
            'winners': len(winners),
            'losers': len(losers),
            'net_profit': net_profit,
            'net_profit_pct': net_profit / self.params.initial_balance * 100,
            'win_rate': win_rate,
            'profit_factor': profit_factor,
            'max_drawdown': max_drawdown,
            'sharpe_ratio': sharpe,
            'avg_trade_pnl': avg_trade_pnl,
            'avg_bars_held': avg_bars_held,
            'gross_profit': gross_profit,
            'gross_loss': gross_loss,
            'final_balance': self.params.initial_balance + net_profit,
            'exit_reasons': exit_reasons,
            'trades': self.trades
        }
        
        return results


# ============================================================
# OPTIMIZATION ENGINE
# ============================================================
def optimize_strategy(df, param_grid=None):
    """
    Optimize strategy parameters through grid search.
    Focus on parameters that affect spike detection quality and exit timing.
    """
    if param_grid is None:
        param_grid = {
            'min_range_atr': [0.8, 1.0, 1.15, 1.3],
            'max_range_atr': [2.0, 2.5, 2.8, 3.5],
            'sl_atr_mult': [1.0, 1.2, 1.5, 2.0],
            'rr_ratio': [1.5, 2.0, 2.5, 3.0],
            'min_body_ratio': [0.40, 0.50, 0.55, 0.65],
            'min_vol_mult': [1.2, 1.4, 1.6, 2.0],
            'max_hold_bars': [6, 8, 10, 12, 15],
            'trail_atr_mult': [0.8, 1.0, 1.2, 1.5],
            'min_squeeze_bars': [2, 3, 4, 5],
            'kc_atr_mult': [1.2, 1.5, 1.8, 2.0],
        }
    
    # Generate parameter combinations (sampled for efficiency)
    import itertools
    
    # Limit combinations for practical runtime
    keys = list(param_grid.keys())
    values = list(param_grid.values())
    
    # Sample a subset of combinations
    all_combos = list(itertools.product(*values))
    np.random.seed(42)
    if len(all_combos) > 500:
        indices = np.random.choice(len(all_combos), 500, replace=False)
        combos = [all_combos[i] for i in indices]
    else:
        combos = all_combos
    
    print(f"\n{'='*60}")
    print(f"OPTIMIZATION: Testing {len(combos)} parameter combinations...")
    print(f"{'='*60}")
    
    best_score = -999
    best_params = None
    best_results = None
    results_log = []
    
    for i, combo in enumerate(combos):
        params_dict = dict(zip(keys, combo))
        params = SpikeHunterParams(**params_dict)
        
        bt = SpikeHunterBacktester(df, params)
        results = bt.run_backtest()
        
        # Score: weighted combination of metrics
        # Prioritize: profit, win_rate, profit_factor, and low drawdown
        if results['total_trades'] < 5:
            score = -100
        else:
            score = (
                results['net_profit_pct'] * 2.0 +           # Profit weight
                results['win_rate'] * 0.5 +                  # Win rate weight
                min(results['profit_factor'], 5) * 10.0 +    # PF weight (capped)
                results['max_drawdown'] * 0.3 +              # Drawdown penalty (negative)
                results['sharpe_ratio'] * 0.1                # Risk-adjusted
            )
        
        results_log.append({
            'params': params_dict,
            'score': score,
            'trades': results['total_trades'],
            'net_profit': results['net_profit'],
            'net_profit_pct': results['net_profit_pct'],
            'win_rate': results['win_rate'],
            'profit_factor': results['profit_factor'],
            'max_drawdown': results['max_drawdown'],
            'sharpe': results['sharpe_ratio']
        })
        
        if score > best_score:
            best_score = score
            best_params = params_dict.copy()
            best_results = results
            
            if (i + 1) % 50 == 0 or score > best_score:
                print(f"  [{i+1}/{len(combos)}] New best: Score={score:.1f} | "
                      f"Trades={results['total_trades']} | "
                      f"Profit={results['net_profit_pct']:.1f}% | "
                      f"WR={results['win_rate']:.1f}% | "
                      f"PF={results['profit_factor']:.2f} | "
                      f"DD={results['max_drawdown']:.1f}%")
    
    # Sort results by score
    results_df = pd.DataFrame(results_log)
    results_df = results_df.sort_values('score', ascending=False)
    
    print(f"\n{'='*60}")
    print(f"OPTIMIZATION COMPLETE")
    print(f"{'='*60}")
    print(f"Best Parameters: {best_params}")
    print(f"Best Score: {best_score:.1f}")
    
    return best_params, best_results, results_df


# ============================================================
# MAIN EXECUTION
# ============================================================
def print_results(results, title="BACKTEST RESULTS"):
    """Pretty print backtest results"""
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")
    print(f"  Total Trades:      {results['total_trades']}")
    print(f"  Winners:           {results.get('winners', 0)}")
    print(f"  Losers:            {results.get('losers', 0)}")
    print(f"  Win Rate:          {results['win_rate']:.1f}%")
    print(f"  Net Profit:        ${results['net_profit']:.2f} ({results['net_profit_pct']:.2f}%)")
    print(f"  Profit Factor:     {results['profit_factor']:.2f}")
    print(f"  Max Drawdown:      {results['max_drawdown']:.2f}%")
    print(f"  Sharpe Ratio:      {results['sharpe_ratio']:.2f}")
    print(f"  Avg Trade PnL:     ${results['avg_trade_pnl']:.2f}")
    print(f"  Avg Bars Held:     {results['avg_bars_held']:.1f}")
    print(f"  Final Balance:     ${results['final_balance']:.2f}")
    print(f"  Exit Reasons:      {results.get('exit_reasons', {})}")
    print(f"{'='*60}")


def main():
    print("=" * 60)
    print("  SpikeHunter - Gold M5 Spike Detection Strategy")
    print("  Python Backtest & Optimization Engine")
    print("=" * 60)
    
    # Step 1: Download data
    print("\n[STEP 1] Acquiring XAUUSD M5 data...")
    df = download_gold_data()
    print(f"Data shape: {df.shape}")
    print(f"Date range: {df.index[0]} to {df.index[-1]}")
    print(f"Price range: ${df['close'].min():.2f} - ${df['close'].max():.2f}")
    
    # Step 2: Run initial backtest with default parameters
    print("\n[STEP 2] Running initial backtest with default parameters...")
    default_params = SpikeHunterParams()
    bt = SpikeHunterBacktester(df, default_params)
    initial_results = bt.run_backtest()
    print_results(initial_results, "INITIAL BACKTEST (Default Parameters)")
    
    # Step 3: Optimize parameters
    print("\n[STEP 3] Optimizing strategy parameters...")
    best_params, best_results, opt_log = optimize_strategy(df)
    
    # Step 4: Run final backtest with optimized parameters
    print("\n[STEP 4] Running final backtest with optimized parameters...")
    optimized_params = SpikeHunterParams(**best_params)
    bt_final = SpikeHunterBacktester(df, optimized_params)
    final_results = bt_final.run_backtest()
    print_results(final_results, "FINAL OPTIMIZED BACKTEST")
    
    # Step 5: Show improvement
    print("\n[STEP 5] Optimization Summary")
    print("-" * 60)
    print(f"{'Metric':<25} {'Initial':<15} {'Optimized':<15} {'Change':<15}")
    print("-" * 60)
    
    metrics = [
        ('Total Trades', initial_results['total_trades'], final_results['total_trades'], ''),
        ('Win Rate (%)', f"{initial_results['win_rate']:.1f}", f"{final_results['win_rate']:.1f}", '%'),
        ('Net Profit ($)', f"${initial_results['net_profit']:.2f}", f"${final_results['net_profit']:.2f}", ''),
        ('Net Profit (%)', f"{initial_results['net_profit_pct']:.2f}%", f"{final_results['net_profit_pct']:.2f}%", ''),
        ('Profit Factor', f"{initial_results['profit_factor']:.2f}", f"{final_results['profit_factor']:.2f}", ''),
        ('Max Drawdown (%)', f"{initial_results['max_drawdown']:.2f}%", f"{final_results['max_drawdown']:.2f}%", ''),
        ('Sharpe Ratio', f"{initial_results['sharpe_ratio']:.2f}", f"{final_results['sharpe_ratio']:.2f}", ''),
        ('Avg Bars Held', f"{initial_results['avg_bars_held']:.1f}", f"{final_results['avg_bars_held']:.1f}", ''),
    ]
    
    for name, init_val, opt_val, unit in metrics:
        print(f"  {name:<23} {str(init_val):<15} {str(opt_val):<15}")
    
    # Step 6: Show top 10 parameter sets
    print("\n\n[STEP 6] Top 10 Parameter Sets from Optimization")
    print("-" * 80)
    top10 = opt_log.head(10)
    for i, row in top10.iterrows():
        print(f"  Rank {top10.index.get_loc(i)+1}: Score={row['score']:.1f} | "
              f"Profit={row['net_profit_pct']:.1f}% | WR={row['win_rate']:.1f}% | "
              f"PF={row['profit_factor']:.2f} | DD={row['max_drawdown']:.1f}%")
        print(f"    Params: {row['params']}")
    
    # Step 7: Sample trades
    if final_results['trades']:
        print("\n\n[STEP 7] Sample Trades (First 10)")
        print("-" * 100)
        for t in final_results['trades'][:10]:
            direction = "BUY" if t['direction'] == 1 else "SELL"
            print(f"  {t['entry_time'].strftime('%Y-%m-%d %H:%M')} | {direction} | "
                  f"Entry=${t['entry_price']:.2f} | Exit=${t['exit_price']:.2f} | "
                  f"PnL=${t['pnl']:.2f} | {t['exit_reason']} | {t['signal_type']} | "
                  f"Held={t['bars_held']} bars")
    
    print("\n\n" + "=" * 60)
    print("  OPTIMIZATION COMPLETE")
    print("=" * 60)
    
    return final_results, best_params


if __name__ == "__main__":
    results, best_params = main()
